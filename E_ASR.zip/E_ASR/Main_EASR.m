% Main script with example.
clc;
clear all;
close all;

% Load dataset
load subject_1.mat;

fs = 500;  % sampling frequency

% EmbeddedASR on Fp1
% specify channel number of interest
% 1 for Fp1 channel 
channel = 1; 
signal_original = double(EEG.data(channel, 170501:200500)); %1 minute input data

% To generate E-ASR cleaned single channel data. 
[EASR_Cleaned_Sig,  signal_original_easr,elapsed_time] = embeddedASR(signal_original,channel,fs);

% Counts the number of eye blinks before and after application of ASR and EASR
[beforeEASR,afterEASR] = eye_blink_count(signal_original_easr,EASR_Cleaned_Sig,fs);


